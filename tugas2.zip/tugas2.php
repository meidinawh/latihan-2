<?php
for ($genap = 2; $genap <= 20; $genap++){
        if ($genap % 2 == 0) {
        echo $genap. "<br>";
        } 
}
?>
